var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/models.js")
R.c("server/chunks/[root-of-the-server]__f709502e._.js")
R.c("server/chunks/[root-of-the-server]__f4541fd4._.js")
R.m(9743)
module.exports=R.m(9743).exports
