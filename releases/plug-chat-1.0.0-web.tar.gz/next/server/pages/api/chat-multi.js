var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/chat-multi.js")
R.c("server/chunks/[root-of-the-server]__5f2f7961._.js")
R.c("server/chunks/[root-of-the-server]__f4541fd4._.js")
R.m(9996)
module.exports=R.m(9996).exports
