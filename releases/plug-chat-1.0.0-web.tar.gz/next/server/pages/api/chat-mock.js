var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/chat-mock.js")
R.c("server/chunks/[root-of-the-server]__bba6061a._.js")
R.c("server/chunks/[root-of-the-server]__f4541fd4._.js")
R.m(7773)
module.exports=R.m(7773).exports
