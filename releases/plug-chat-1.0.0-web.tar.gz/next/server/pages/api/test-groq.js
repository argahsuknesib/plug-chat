var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/test-groq.js")
R.c("server/chunks/[root-of-the-server]__c3e602c8._.js")
R.c("server/chunks/[root-of-the-server]__f4541fd4._.js")
R.m(9671)
module.exports=R.m(9671).exports
