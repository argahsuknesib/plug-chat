self.__BUILD_MANIFEST = {
  "/": [
    "./static/chunks/948f29cddf048cdc.js"
  ],
  "/_error": [
    "./static/chunks/a2cdbcc4ab67aa5d.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/_app",
    "/_error",
    "/api/chat",
    "/api/chat-mock",
    "/api/chat-multi",
    "/api/models",
    "/api/test-groq"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()