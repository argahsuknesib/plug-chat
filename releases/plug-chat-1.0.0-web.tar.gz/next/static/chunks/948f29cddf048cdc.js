__turbopack_load_page_chunks__("/", [
  "static/chunks/54f0ed99aa1cd169.js",
  "static/chunks/8a4e9b803a01d39e.js",
  "static/chunks/c8a2e3094391ccca.js",
  "static/chunks/turbopack-c33106d92e942874.js"
])
