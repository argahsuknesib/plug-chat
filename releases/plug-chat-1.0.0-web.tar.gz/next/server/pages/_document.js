var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__d884b508._.js")
R.c("server/chunks/ssr/[root-of-the-server]__2db1479a._.js")
R.m(9141)
module.exports=R.m(9141).exports
