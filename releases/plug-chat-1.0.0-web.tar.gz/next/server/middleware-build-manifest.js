globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/54f0ed99aa1cd169.js",
      "static/chunks/8a4e9b803a01d39e.js",
      "static/chunks/c8a2e3094391ccca.js",
      "static/chunks/turbopack-c33106d92e942874.js"
    ],
    "/_app": [
      "static/chunks/98d345ddc6b79406.js",
      "static/chunks/8a4e9b803a01d39e.js",
      "static/chunks/turbopack-bd41e4306243fc88.js"
    ],
    "/_error": [
      "static/chunks/1abb0d3334717a28.js",
      "static/chunks/8a4e9b803a01d39e.js",
      "static/chunks/turbopack-9dc9294bcefcc2dd.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];