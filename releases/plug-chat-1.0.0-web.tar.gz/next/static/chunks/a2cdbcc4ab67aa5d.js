__turbopack_load_page_chunks__("/_error", [
  "static/chunks/1abb0d3334717a28.js",
  "static/chunks/8a4e9b803a01d39e.js",
  "static/chunks/turbopack-9dc9294bcefcc2dd.js"
])
