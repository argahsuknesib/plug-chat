__turbopack_load_page_chunks__("/_app", [
  "static/chunks/98d345ddc6b79406.js",
  "static/chunks/8a4e9b803a01d39e.js",
  "static/chunks/turbopack-bd41e4306243fc88.js"
])
