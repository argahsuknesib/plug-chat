var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/chat.js")
R.c("server/chunks/[root-of-the-server]__226ce85b._.js")
R.c("server/chunks/[root-of-the-server]__f4541fd4._.js")
R.m(2801)
module.exports=R.m(2801).exports
